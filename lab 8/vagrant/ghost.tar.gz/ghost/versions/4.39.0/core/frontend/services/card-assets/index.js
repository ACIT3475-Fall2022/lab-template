const CardAssetService = require('./service');
let cardAssetService = new CardAssetService();

module.exports = cardAssetService;
