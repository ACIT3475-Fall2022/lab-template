const {
    addPermissionToRole
} = require('../../utils');

module.exports = addPermissionToRole({
    permission: 'Read member signin urls',
    role: 'Administrator'
});
