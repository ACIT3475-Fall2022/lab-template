module.exports = {
    async up(){},
    async down(){}
};
