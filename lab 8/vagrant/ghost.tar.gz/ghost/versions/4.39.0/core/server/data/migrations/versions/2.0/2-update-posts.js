module.exports.up = () => {
    // noop - superceded by later majors performing re-render
};

module.exports.down = () => {
    // noop - superceded by later majors performing re-render
};
