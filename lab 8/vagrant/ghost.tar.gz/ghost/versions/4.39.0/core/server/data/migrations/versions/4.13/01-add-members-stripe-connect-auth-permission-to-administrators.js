const {addPermissionToRole} = require('../../utils');

module.exports = addPermissionToRole({
    permission: 'Auth Stripe Connect for Members',
    role: 'Administrator'
});
