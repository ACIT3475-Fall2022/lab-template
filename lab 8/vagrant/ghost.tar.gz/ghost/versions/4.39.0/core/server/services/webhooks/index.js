module.exports = {
    get listen() {
        return require('./listen');
    }
};
