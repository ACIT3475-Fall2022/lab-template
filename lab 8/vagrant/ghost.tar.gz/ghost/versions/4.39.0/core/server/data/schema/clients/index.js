const sqlite3 = require('./sqlite3');
const mysql = require('./mysql');

module.exports = {
    sqlite3: sqlite3,
    mysql2: mysql
};
